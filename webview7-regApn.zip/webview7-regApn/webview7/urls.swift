//
//  urls.swift
//  webview7
//
//  Created by Admin on 2/8/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

//let urls = "http://104.128.238.15:3000";
let url = "http://10.0.0.1:3000";
let msgUrl = url + "/msg";
let addUrl = url + "/add";
